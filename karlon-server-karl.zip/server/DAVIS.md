> **Davis is now called Karl.** What changed and why (the October chat review, Claude, the
> communication model, memory, invoices): see [KARL.md](KARL.md).

# Davis: KarlCon Elite Retreats' WhatsApp reception and booking assistant

Davis reads every guest message that reaches Karlon from WhatsApp. It decides whether to answer, and then moves
the guest from "hello" to a paid booking:

```
greeting → city + dates + guests → live homes for those exact dates (Airbnb scraper, on demand)
        → 3 houses with photos → guest picks a KCER → full name + ID → invoice PDF + Terms PDF
        → "I have paid" / proof photo → Davis thanks them; confirmation follows once it reflects
```

**No human in the middle.** Davis runs the whole conversation itself. There is no "needs staff" alert and no
hand-over: complaints, requests for a person, payment proofs, questions nobody has answered before and late
prices are all handled by Davis. Its hands are WhatsApp (the outbox) and Airbnb (the scraper, which fetches
homes for the dates a guest asks for). A person can still mute Davis in one chat with **Take over** on the
dashboard; nothing ever asks them to.

Davis runs inside the Karlon server on the Karlon Space, next to the outbox, the house catalogue and the invoice
queue. What it sends goes through the same outbox to `wa_bridge.py` as anything sent from the app.

**There is no external AI service.** Davis's language model is a small open model (Qwen2.5 1.5B Instruct,
4-bit GGUF, about 1.1 GB). It runs on the Space's own CPU with llama.cpp. There is no API key, and no guest
message leaves the Space.

## Who Davis is: `app/davis/persona.py`

One file holds Davis's identity, voice, selling style and limits, plus **every line Davis says**. Edit it to
change how Davis sounds:

- `PERSONA` sets the character: warm, quick and confident, like a five-star front desk. Davis greets back in
  Shona or Ndebele, uses one emoji at most, asks one question per message, and always gives the next step.
  It also lists the hard "never" rules: no invented prices or amenities, no links, no Airbnb, never pretends
  to be human.
- `LINES` holds the exact sentences for each situation: greeting, asking dates, presenting houses, confirming
  the choice, asking for name and ID, invoice sent, payment, complaints, follow-ups, and so on. Each one is under 40 words
  (a test checks this).
- `EXAMPLES` are worked examples shown to the model.
- `PAYMENT` holds the EcoCash details: **0780563561 (Karl Muzunze)**. Davis gives them when a guest asks
  how to pay, with the invoice, and after it. The guard blocks any reply containing a different number, so
  no other payment number can ever be sent. The invoice PDF prints the same details
  (`pc-bridge/invoice_worker.py`, `ECOCASH_NUMBER` / `ECOCASH_NAME`).

## AI only (the default): the model writes every reply

`DAVIS_LLM_FOR=ai`, shown in the dashboard as Settings → Model writes → "AI only".

**How a reply is made:**
- **Code decides what happens:** which houses to send, the invoice, the Terms, live-home requests. It also works out the
  **key points** a message must get across, from the persona lines, FAQ, house notes and skills.
- **The AI writes the message itself**, in its own words, reacting to what the guest said, with the whole
  recent chat in view (guest, Davis and staff).

**How it's checked.** Each AI reply passes a check before it's sent. It must keep every exact detail from the
key points: the EcoCash number, KCER numbers, totals, times, dates, and the viewing and payment policies. It
must not invent numbers, links or houses, or write as the guest.

**If the check fails:**
- The AI gets one retry at once, told what to fix.
- If that fails too, nothing is sent yet: the whole turn runs again after `DAVIS_AI_RETRY_SEC` (40 s), up to
  `DAVIS_AI_RETRIES` (2) times. A busy or cold model usually succeeds then.
- If it still fails, the plan's own wording (the key points, from the persona lines) goes out, so a guest is
  never left waiting for a person. The dashboard shows such replies as `reply(plan)`.
- The same happens if the model is down.

**Measured with the local 1.5B model on 2 CPUs:**
- Taku's real conversation (15 messages): 14 replies written by the AI, all correct.
- The no-staff paths (open questions, complaint, "a real person", payment proof, follow-up): every reply
  written by the AI and sent; 8–20 s each once the model is warm.

A larger model (hosted, a bigger CPU or a GPU) makes it faster and smarter with no code change: set
`DAVIS_PROVIDER` / the model.

The other modes keep the older behaviour:
- `all`: the AI rewrites the fixed lines.
- `open`: fixed lines, AI only for open questions.

## Where the model is used in "open" mode, and why

The booking itself is code: understanding the message, deciding the step, choosing houses and the exact
reply. The persona's lines go out **instantly** and are always correct.

The local model answers **open questions that a team note can answer** ("does KCER 102 have wifi?"). Write
notes per house on the dashboard (Catalogue → team note: "wifi, pool, borehole, solar backup").

1. If the question shares a word with a house's note, Davis replies with the note ("KCER 102 has wifi, pool,
   solar backup ✨ …").
2. The model may reword that reply. Its answer must still pass the guard and must use the note's word.
3. If no note covers the question ("can we bring our dog?", "is it near the airport?"), Davis says plainly
   that detail isn't in the listing and continues with the next booking step. Nobody is alerted, nothing is
   promised. The model isn't asked in this mode, so there's no wait.

This was decided from real tests of the 1.5B model on 2 CPU threads:

- It sometimes wrote as the guest ("Hello Davis! I'd like to stay…").
- It once invented a fact ("near the airport") that no note contained.
- Each reply took 5–20 s.

The guard now rejects all of these. With the model on booking steps the bookings were slower and no better.
You can still switch the dashboard's Settings → "Model writes" to **every reply**. Each rewrite must keep the
draft's KCERs, amounts and closing question, or the persona line goes out. A bigger model on better hardware
(Ollama on a GPU PC, `DAVIS_PROVIDER=ollama`) makes that mode worthwhile.

**The guard** (`policy.check_reply`) rejects a model reply that:

- has more than 40 words;
- contains any number not in the draft or the facts (no invented prices, dates or counts);
- names a KCER not in play;
- has a link or mentions Airbnb;
- is written in the guest's voice;
- drops the draft's KCER, amount or closing question (in "every reply" mode).

## Answers without "let me ask the team"

Davis answers questions in this order and never says "let me confirm with our team" or "I'll get back to you":

1. **Business FAQ** (`persona.FAQS`, permanent):
   - company and registration (KARLCON Consultancy (Private) Limited, Reg. No. 15017/2023)
   - payment deadline (48 hours) and deposits (full payment confirms)
   - the service fee, and the website
   - viewings and check-in/out (in the persona lines)
2. **House notes** written by the team on the dashboard (Catalogue).
3. **Skills** (`skills.py`, dashboard → Skills): how the team answered similar questions in other chats.
   - A guest's question followed by a team member's reply becomes a skill.
   - It's kept only if the reply is 3–40 words, with no numbers, links or the guest's name.
   - Davis reuses it when a new question shares at least two key words.
   - Staff can add skills by hand, or switch off and delete any.
   - Skills are relearned from the chats every 10 minutes and after each restart. Hand-added skills are lost on
     restart, so put permanent ones in `persona.FAQS`.
4. **Otherwise:** "That detail isn't in our listing for this home, sorry", followed by the next booking step.
   Honest, and no promise that someone will come back.

**Prices match the invoice.** Davis quotes the invoice's Balance Due: nights × rate plus the 15% service
fee, rounded exactly as `invoice_worker.py` rounds it (`DAVIS_SERVICE_FEE_PCT`, default 15).

## The rules you asked for, and where they are enforced

| Rule | Where |
|---|---|
| A message never exceeds 40 words | persona lines (tested), `nlu.clip_words` on every reply, the guard, `catalogue.compact_card` |
| One reply, at most 2 per guest turn, then wait for the guest | `gate.davis_replies_this_turn` + `Engine._cap`; Davis speaks only when the guest spoke last (the second reply is only "here are the houses" after "checking live prices…") |
| Decide whether to answer at all | `gate.decide`: off/paused, allow/ignore lists, group chats, messages older than 3 days, already answered, opted out, "Take over" pressed on the dashboard, a plain "ok/thanks" |
| No human in the middle | `policy.plan` has no hand-over action; complaints, "a person", payments, open questions and late prices are answered by Davis (`test_no_staff_actions_anywhere`) |
| Houses only for the dates asked | `request_refresh` → `refresh_jobs` → the scraper's on-demand loop; first homes sent at `DAVIS_EARLY_PRESENT` (3) |
| Send T&Cs and the invoice | `send_terms` (`messages.queue_terms`), `create_invoice` (`invoices.create_invoice`, `created_by="Davis"`) |
| Houses with images per city from the existing endpoints | `catalogue.find_options` → `houses.available_listings`; `houses.queue_listings` (shared with `POST /api/houses/send`) |
| Session memory | `davis_sessions`, the booking frame, rebuilt from chat history after a restart |
| Caching, pooling, process management | see "Speed" |

## Modes (dashboard: `/davis`)

- **OFF**: Davis does nothing.
- **SHADOW** (the default): Davis drafts; you approve (and can edit) or discard each draft on the dashboard.
  Use it for a trial run; LIVE is the no-human mode.
- **LIVE**: Davis replies by itself.

Per chat you can pause Davis, take the chat over, give it back, reset its memory, or run it now. **Only these
chats** in Settings is the safe way to go live with one or two test chats first.

## How a message is handled

1. **Hook.** The bridge sync, the legacy import and inbound photos call `davis.notify_inbound`. A sweeper
   every 30 s catches anything a hook missed.
2. **Debounce, 5 s.** People type in bursts, so a burst is read as one turn (Sacks, Schegloff & Jefferson
   1974).
3. **Admission.** A global semaphore and one lock per chat (SEDA: Welsh, Culler & Brewer 2001).
4. **Preprocess** (`nlu.py`, no model, under 1 ms): intents and slots (city or suburb, dates in every format
   guests use, guests, budget, KCER / "option 2", full name, Zimbabwe ID or passport).
5. **Gate** (`gate.py`): answer or not, with a reason on the dashboard. Turn order uses arrival order,
   because WhatsApp stamps guest messages to the minute.
6. **Claim.** An atomic update, so a message is never answered twice.
7. **Policy** (`policy.py`): a frame-based booking dialogue (GUS: Bobrow et al. 1977; dialog state tracking:
   Williams, Raux & Henderson 2016). Code decides the actions and picks the persona line.
8. **Model** (`local_llm.py`): only where described above, always behind the guard.
9. **Execute or draft.** The reply first, then house cards and photos, the invoice, the Terms PDF.
10. **Events and metrics** go to the dashboard over the WebSocket `/api/davis/ws`.

## The catalogue fills on demand

The scraper no longer sweeps every city on a timer (`AIRBNB_FULL_SWEEP=0`, the default). The catalogue is what
guests ask for:

1. A guest gives a city and dates. If there are no prices for exactly those dates, Davis queues a live request
   (`refresh_jobs`) and says it's checking.
2. The scraper picks it up within 5 s (`AIRBNB_ONDEMAND_POLL_SEC`), works up to 2 requests at once
   (`AIRBNB_ONDEMAND_PARALLEL`), searches Airbnb for that city and those dates, and pushes each home as soon as
   it's priced.
3. When the first 3 homes are in (`DAVIS_EARLY_PRESENT`), Davis sends them, without waiting for the rest.
   "More options" sends the others.
4. If nothing arrives within 12 minutes (`DAVIS_REFRESH_TIMEOUT_MINUTES`), Davis asks the scraper once more,
   quietly. If that also fails, it tells the guest plainly and offers other dates or a nearby area.

The dashboard's Catalogue tab shows these live requests (pending, searching, done, guests waiting), and
"Fetch homes" queues one by hand.

## Operating norms (built into the code)

1. **Davis always has the last word.** Every guest message from the last 3 days gets a reply, even right after
   a staff reply. The only exceptions are a plain "ok/thanks", group chats, the ignore list, opt-outs, and
   chats where staff pressed **Take over** on the dashboard.
2. **No hand-over.** A complaint gets an apology and "what exactly went wrong?"; "speak to a person" gets "you're
   speaking with Davis, I can do everything here"; a payment proof is thanked, with the confirmation to follow
   once it reflects; a question nothing answers is said plainly. Nobody is alerted.
3. **Customer care.** A guest who goes quiet mid-booking (houses sent, details or payment pending) gets one
   friendly nudge after `DAVIS_FOLLOWUP_HOURS` (3 h), only while their last message is under 23 h old. When they
   write again, a later silence may get one more.
4. **Every reply ends with the next step**: city and dates → which KCER → name and ID → pay by EcoCash.
5. **House policies are answered, not escalated:**
   - No viewings before a reservation; once payment is confirmed the guest gets the live location and host
     address.
   - Check-in is from 2:00 PM, check-out by 10:00 AM.
   - Payment is by EcoCash 0780563561 (Karl Muzunze).
6. **Never lost, always running.**
   - If a pass fails, the guest's message is released and retried.
   - A sweeper re-checks every 30 s for unanswered guests, late live requests and quiet guests, and a watchdog
     restarts it if it ever stops.
   - If the model is slow or down, the turn is retried, then the plan's wording goes out.

## Speed

- **Debounce** 5 s (was 8). With the AI writing every reply, the model's time is most of the wait: 8–20 s
  per reply on the Space's 2 CPUs. A bigger CPU or a GPU Space cuts that with no code change.
- **Local model (open questions):**
  - The model loads and computes the persona prefix at boot, so the first guest doesn't wait for it.
  - The persona and examples never change, so llama.cpp reuses that computed prefix and only reads each
    turn's new text.
  - The answer is constrained to `{"reply"}` JSON by a grammar, so the output is short.
  - Threads are set to the container's real CPU quota. Oversubscribing threads is what collapsed the
    Conscious Worker to under 1 token/s.
  - Measured: about 5–8 s per answer on 2 threads.
- **Timeout and breaker:** after 45 s, or after 3 failures in a row, the model is skipped for a minute and the
  turn is retried (Dean & Barroso, "The Tail at Scale", 2013).
- **Caches:** catalogue queries per (city, dates) are cached for 60 s; model answers are cached per prompt.
- **Why it matters:** in an audit of 2,241 firms only 37% answered a web lead within an hour (Oldroyd,
  McElheran & Elkington, HBR 2011). Speed to lead is on the dashboard.

## Setup on the Karlon Space

The Dockerfile installs llama.cpp as a prebuilt CPU wheel (no compiling) and downloads the model into the
image at build time. The first build takes a few minutes longer; later builds reuse the cached layer.

Space variables and secrets (Settings → Variables and secrets):

| Name | Value |
|---|---|
| `DAVIS_MODE` | `shadow` to start; switch to live on the dashboard |
| `KARLON_PASSWORD` (secret) | the password for the Karlon web page and the Davis dashboard. **Required:** without it the Davis dashboard stays locked |

Optional:

| Name | Default | Notes |
|---|---|---|
| `DAVIS_PROVIDER` | `local` | `ollama`, `worker` or `rules` |
| `DAVIS_LLM_FOR` | `ai` | `all` / `open` = older modes |
| `DAVIS_LOCAL_MODEL_REPO`, `DAVIS_LOCAL_MODEL_FILE` | | change them together with the Dockerfile's `ENV` lines |
| `DAVIS_LOCAL_THREADS` | auto | |
| `DAVIS_MAX_WORDS` | 40 | |
| `DAVIS_MAX_REPLIES_PER_TURN` | 2 | |
| `DAVIS_DEBOUNCE_SEC` | 5 | |
| `DAVIS_AI_RETRIES`, `DAVIS_AI_RETRY_SEC` | 2, 40 | re-runs of a turn whose AI reply failed, before the plan's wording |
| `DAVIS_EARLY_PRESENT` | 3 | send homes as soon as this many are priced for the guest's dates |
| `DAVIS_REFRESH_TIMEOUT_MINUTES`, `DAVIS_REFRESH_TRIES` | 12, 2 | live request deadline; requests before "other dates?" |
| `DAVIS_FOLLOWUP_HOURS`, `DAVIS_FOLLOWUP_MAX` | 3, 1 | the nudge to a quiet guest (0 = off) |
| `DAVIS_FRESH_MINUTES` | 4320 | 3 days; older messages aren't answered |
| `DAVIS_HUMAN_QUIET_MINUTES` | 0 | 0 = Davis replies even right after a person writes in the chat |
| `DAVIS_IGNORE_CHATS` | | comma-separated chat ids Davis never answers (survives restarts) |
| `DAVIS_ONLY_CHATS` | | comma-separated chat ids for a test rollout |

For Ollama elsewhere: `DAVIS_PROVIDER=ollama`, `DAVIS_OLLAMA_URL`, `DAVIS_OLLAMA_MODEL`.

The model needs about 2 GB of RAM; the free CPU Space has 16 GB.

Open `https://<space>/davis`. The page stays blurred behind a lock screen until the Karlon password is
entered. The server checks the password on every Davis data call and on the live feed, so the blur is only the
visible part of the lock. 🔒 Lock (top right) locks it again on that device. Settings shows the local model's state
(loading / ready / error), its load time and the last reply's speed.

**Rollout:**
1. Run in shadow mode for a day.
2. Add team notes for your houses.
3. Put one test chat in "Only these chats" and switch to LIVE.
4. Empty the list when happy.

## Things to know

- **WhatsApp's terms.** Automating WhatsApp Web (wa_bridge) is against WhatsApp's terms, and a number can be
  banned, more likely with fast automated replies. The WhatsApp Business Platform (Cloud API) is the durable
  route; only the delivery step would change.
- **Restarts.** The Space has no persistent disk, so a restart wipes Davis's settings and memory along with
  the rest of the database. Davis rebuilds each frame from the re-synced chats. After a restart it answers every
  guest whose last message (within 3 days) is still unanswered, so keep `DAVIS_IGNORE_CHATS` up to date for
  family, team and supplier chats.
- **Prices** come only from the dated offers the scraper stored for the guest's dates.
- **Payment.** Davis can't see the EcoCash account, so it never says a booking is confirmed: it thanks the guest
  for the proof and says the confirmation, live location and host address follow once the payment reflects.
  Group chats are never answered.

## Code map

```
app/davis/
  persona.py    who Davis is: character, voice, selling style, limits, every line, model examples
  config.py     environment defaults (modes, limits, provider, local model)
  nlu.py        preprocessing: intents and slots from text
  gate.py       answer or not (turn-taking, freshness, groups, caps, "Take over")
  policy.py     the booking dialogue: actions + persona lines; note grounding; reply guard
  catalogue.py  live catalogue: options per city/dates, house cards, which option the guest means
  prompts.py    model messages: persona + examples (fixed prefix) + this turn
  local_llm.py  the local model: llama.cpp, warm-up, CPU threads, JSON grammar
  llm.py        providers (local, Ollama, Conscious Worker), breaker, cache
  engine.py     debounce, admission, pipeline, AI retries, follow-ups, outbox execution, metrics, live feed
  skills.py     answers learned from the team's replies in chats (and added on the dashboard)
  store.py      tables: davis_settings, davis_sessions, davis_events, davis_drafts, davis_catalogue, davis_skills
  router.py     /davis, /api/davis/ws, /api/davis/*
static/davis.html  the dashboard
tests/test_davis.py
```

## References

- Bobrow, D. G., Kaplan, R. M., Kay, M., Norman, D. A., Thompson, H., & Winograd, T. (1977). GUS, a
  frame-driven dialog system. *Artificial Intelligence*, 8(2), 155–173. doi:10.1016/0004-3702(77)90018-2
- Williams, J. D., Raux, A., & Henderson, M. (2016). The Dialog State Tracking Challenge Series: A Review.
  *Dialogue & Discourse*, 7(3), 4–33. doi:10.5087/dad.2016.301
- Sacks, H., Schegloff, E. A., & Jefferson, G. (1974). A simplest systematics for the organization of
  turn-taking for conversation. *Language*, 50(4), 696–735. doi:10.1353/lan.1974.0010
- Grice, H. P. (1975). Logic and conversation. In *Syntax and Semantics 3: Speech Acts*, 41–58.
- Welsh, M., Culler, D., & Brewer, E. (2001). SEDA: An Architecture for Well-Conditioned, Scalable Internet
  Services. *SOSP '01*.
- Dean, J., & Barroso, L. A. (2013). The Tail at Scale. *Communications of the ACM*, 56(2), 74–80.
- Oldroyd, J. B., McElheran, K., & Elkington, D. (2011). The Short Life of Online Sales Leads. *Harvard
  Business Review*, 89(3), 28.
